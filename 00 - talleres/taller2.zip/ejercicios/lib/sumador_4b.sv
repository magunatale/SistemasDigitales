// Sumador de 4 bits del Taller 1. No modificar.
module sumador_4b (
    input  logic [3:0] a,
    input  logic [3:0] b,
    input  logic       cin,
    output logic [3:0] sum,
    output logic       cout
);
  logic c1, c2, c3;

  sumador_completo fa0 (
      .a(a[0]),
      .b(b[0]),
      .cin(cin),
      .sum(sum[0]),
      .cout(c1)
  );

  sumador_completo fa1 (
      .a(a[1]),
      .b(b[1]),
      .cin(c1),
      .sum(sum[1]),
      .cout(c2)
  );

  sumador_completo fa2 (
      .a(a[2]),
      .b(b[2]),
      .cin(c2),
      .sum(sum[2]),
      .cout(c3)
  );

  sumador_completo fa3 (
      .a(a[3]),
      .b(b[3]),
      .cin(c3),
      .sum(sum[3]),
      .cout(cout)
  );
endmodule
